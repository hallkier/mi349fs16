

function textPopup() {
    
    document.getElementById("info").innerHTML = "You Signed Up!";
}
