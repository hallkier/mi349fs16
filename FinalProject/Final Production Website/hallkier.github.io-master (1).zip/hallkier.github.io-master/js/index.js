
function myFunction() {
    document.getElementById("demo").innerHTML = "Thanks for signing up!";
}


